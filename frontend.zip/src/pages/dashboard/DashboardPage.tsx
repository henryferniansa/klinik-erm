import { useEffect, useState } from "react";
import { Users, Calendar, CreditCard, Activity } from "lucide-react";
import api from "../../lib/api";
import type { Appointment, Invoice } from "../../types";

interface Stats {
  totalPatients: number;
  todayAppointments: number;
  todayIncome: number;
  activeServices: number;
}

const statusLabel: Record<string, string> = {
  scheduled: "Menunggu",
  in_progress: "Proses",
  done: "Selesai",
  cancelled: "Batal",
};

const statusColor: Record<string, string> = {
  scheduled: "bg-purple-50 text-purple-700",
  in_progress: "bg-amber-50 text-amber-700",
  done: "bg-green-50 text-green-700",
  cancelled: "bg-red-50 text-red-700",
};

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats>({
    totalPatients: 0,
    todayAppointments: 0,
    todayIncome: 0,
    activeServices: 0,
  });
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [patientsRes, appointmentsRes, servicesRes, invoicesRes] =
          await Promise.all([
            api.get("/patients/"),
            api.get("/appointments/today"),
            api.get("/services/"),
            api.get("/invoices/?status=paid"),
          ]);

        const todayIncome = invoicesRes.data
          .filter((inv: Invoice) => {
            const d = new Date(inv.paid_at ?? "");
            const today = new Date();
            return d.toDateString() === today.toDateString();
          })
          .reduce((sum: number, inv: Invoice) => sum + inv.total_amount, 0);

        setStats({
          totalPatients: patientsRes.data.length,
          todayAppointments: appointmentsRes.data.length,
          todayIncome,
          activeServices: servicesRes.data.length,
        });
        setAppointments(appointmentsRes.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const statCards = [
    {
      label: "Total Pasien",
      value: stats.totalPatients,
      icon: Users,
      color: "#6B2D4E",
      bg: "#F4E6EE",
    },
    {
      label: "Kunjungan Hari Ini",
      value: stats.todayAppointments,
      icon: Calendar,
      color: "#2D7A4F",
      bg: "#E8F5E0",
    },
    {
      label: "Pendapatan Hari Ini",
      value: `Rp ${stats.todayIncome.toLocaleString("id-ID")}`,
      icon: CreditCard,
      color: "#C2610C",
      bg: "#FEF3E2",
    },
    {
      label: "Layanan Aktif",
      value: stats.activeServices,
      icon: Activity,
      color: "#6D28D9",
      bg: "#EDE9FE",
    },
  ];

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold" style={{ color: "#6B2D4E" }}>
            Dashboard
          </h1>
          <p className="text-sm text-gray-400 mt-0.5">
            {new Date().toLocaleDateString("id-ID", {
              weekday: "long",
              day: "numeric",
              month: "long",
              year: "numeric",
            })}
          </p>
        </div>
        <button
          onClick={() => (window.location.href = "/appointments")}
          className="px-4 py-2 text-sm font-medium text-white rounded-lg"
          style={{ backgroundColor: "#2D7A4F" }}
        >
          + Kunjungan Baru
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {statCards.map(({ label, value, icon: Icon, color, bg }) => (
          <div
            key={label}
            className="bg-white rounded-xl p-4 border border-gray-100"
          >
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center mb-3"
              style={{ backgroundColor: bg }}
            >
              <Icon size={16} style={{ color }} />
            </div>
            <div className="text-2xl font-semibold text-gray-800">{value}</div>
            <div className="text-xs text-gray-400 mt-1">{label}</div>
          </div>
        ))}
      </div>

      {/* Tabel Kunjungan */}
      <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <h2 className="text-sm font-semibold" style={{ color: "#6B2D4E" }}>
            Kunjungan Hari Ini
          </h2>
          <span className="text-xs text-gray-400">
            {appointments.length} kunjungan
          </span>
        </div>

        {loading ? (
          <div className="p-8 text-center text-sm text-gray-400">
            Memuat data...
          </div>
        ) : appointments.length === 0 ? (
          <div className="p-8 text-center text-sm text-gray-400">
            Belum ada kunjungan hari ini
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 text-xs text-gray-400 uppercase tracking-wide">
                <th className="px-5 py-3 text-left font-medium">Pasien</th>
                <th className="px-5 py-3 text-left font-medium">Layanan</th>
                <th className="px-5 py-3 text-left font-medium">Terapis</th>
                <th className="px-5 py-3 text-left font-medium">Jam</th>
                <th className="px-5 py-3 text-left font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((apt) => (
                <tr
                  key={apt.id}
                  className="border-t border-gray-50 hover:bg-gray-50 transition-colors"
                >
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                        style={{ backgroundColor: "#F4E6EE", color: "#6B2D4E" }}
                      >
                        {apt.patient?.full_name?.[0] ?? "?"}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-800">
                          {apt.patient?.full_name}
                        </div>
                        <div className="text-xs text-gray-400">
                          {apt.patient?.patient_code}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-sm text-gray-600">
                    {apt.service?.name ?? "-"}
                  </td>
                  <td className="px-5 py-3 text-sm text-gray-600">
                    {apt.therapist?.name ?? "-"}
                  </td>
                  <td className="px-5 py-3 text-sm text-gray-600">
                    {new Date(apt.scheduled_at).toLocaleTimeString("id-ID", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </td>
                  <td className="px-5 py-3">
                    <span
                      className={`text-xs font-medium px-2.5 py-1 rounded-full ${statusColor[apt.status]}`}
                    >
                      {statusLabel[apt.status]}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
