import { useEffect, useState } from "react";
import { Search, Plus } from "lucide-react";
import api from "../../lib/api";
import type { Patient } from "../../types";
import PatientFormModal from "./PatientFormModal";

export default function PatientsPage() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selected, setSelected] = useState<Patient | null>(null);

  const fetchPatients = async () => {
    setLoading(true);
    try {
      const res = await api.get(
        `/patients/${search ? `?search=${search}` : ""}`,
      );
      setPatients(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timeout = setTimeout(fetchPatients, 300);
    return () => clearTimeout(timeout);
  }, [search]);

  const handleAdd = () => {
    setSelected(null);
    setShowModal(true);
  };

  const handleEdit = (patient: Patient) => {
    setSelected(patient);
    setShowModal(true);
  };

  const handleSaved = () => {
    setShowModal(false);
    fetchPatients();
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold" style={{ color: "#6B2D4E" }}>
            Data Pasien
          </h1>
          <p className="text-sm text-gray-400 mt-0.5">
            {patients.length} pasien terdaftar
          </p>
        </div>
        <button
          onClick={handleAdd}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white rounded-lg"
          style={{ backgroundColor: "#6B2D4E" }}
        >
          <Plus size={16} />
          Tambah Pasien
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search
          size={15}
          className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
        />
        <input
          type="text"
          placeholder="Cari nama, NIK, atau kode pasien..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 text-sm border border-gray-200 rounded-lg bg-white outline-none focus:border-green-500 transition-all"
        />
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-sm text-gray-400">
            Memuat data...
          </div>
        ) : patients.length === 0 ? (
          <div className="p-8 text-center text-sm text-gray-400">
            {search ? "Pasien tidak ditemukan" : "Belum ada pasien terdaftar"}
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 text-xs text-gray-400 uppercase tracking-wide">
                <th className="px-5 py-3 text-left font-medium">Pasien</th>
                <th className="px-5 py-3 text-left font-medium">NIK</th>
                <th className="px-5 py-3 text-left font-medium">Telepon</th>
                <th className="px-5 py-3 text-left font-medium">Kota</th>
                <th className="px-5 py-3 text-left font-medium">Asuransi</th>
                <th className="px-5 py-3 text-left font-medium">Terdaftar</th>
                <th className="px-5 py-3 text-left font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {patients.map((p) => (
                <tr
                  key={p.id}
                  className="border-t border-gray-50 hover:bg-gray-50 transition-colors"
                >
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                        style={{ backgroundColor: "#F4E6EE", color: "#6B2D4E" }}
                      >
                        {p.full_name[0]}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-800">
                          {p.full_name}
                        </div>
                        <div className="text-xs text-gray-400">
                          {p.patient_code}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-sm text-gray-600">
                    {p.nik ?? "-"}
                  </td>
                  <td className="px-5 py-3 text-sm text-gray-600">
                    {p.phone ?? "-"}
                  </td>
                  <td className="px-5 py-3 text-sm text-gray-600">
                    {p.address_city ?? "-"}
                  </td>
                  <td className="px-5 py-3">
                    <span
                      className={`text-xs font-medium px-2.5 py-1 rounded-full ${
                        p.insurance_type === "bpjs"
                          ? "bg-blue-50 text-blue-700"
                          : p.insurance_type === "asuransi_swasta"
                            ? "bg-purple-50 text-purple-700"
                            : "bg-gray-100 text-gray-600"
                      }`}
                    >
                      {p.insurance_type === "bpjs"
                        ? "BPJS"
                        : p.insurance_type === "asuransi_swasta"
                          ? "Swasta"
                          : "Umum"}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-sm text-gray-400">
                    {new Date(p.created_at).toLocaleDateString("id-ID")}
                  </td>
                  <td className="px-5 py-3">
                    <button
                      onClick={() => handleEdit(p)}
                      className="text-xs px-3 py-1.5 rounded-lg border border-gray-200 text-gray-500 hover:border-[#6B2D4E] hover:text-[#6B2D4E] transition-colors"
                    >
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <PatientFormModal
          patient={selected}
          onClose={() => setShowModal(false)}
          onSaved={handleSaved}
        />
      )}
    </div>
  );
}
