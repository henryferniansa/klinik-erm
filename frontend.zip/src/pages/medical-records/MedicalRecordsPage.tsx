import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, Search } from "lucide-react";
import api from "../../lib/api";
import type { MedicalRecord } from "../../types";

export default function MedicalRecordsPage() {
  const navigate = useNavigate();
  const [records, setRecords] = useState<MedicalRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  const fetchRecords = async () => {
    setLoading(true);
    try {
      const res = await api.get("/medical-records/");
      setRecords(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecords();
  }, []);

  const filtered = records.filter(
    (r) =>
      r.patient?.full_name?.toLowerCase().includes(search.toLowerCase()) ||
      r.icd10_code?.toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold" style={{ color: "#6B2D4E" }}>
            Rekam Medis
          </h1>
          <p className="text-sm text-gray-400 mt-0.5">
            {records.length} rekam medis
          </p>
        </div>
        <button
          onClick={() => navigate("/medical-records/new")}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white rounded-lg"
          style={{ backgroundColor: "#6B2D4E" }}
        >
          <Plus size={16} />
          Buat Rekam Medis
        </button>
      </div>

      <div className="relative mb-4">
        <Search
          size={15}
          className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
        />
        <input
          type="text"
          placeholder="Cari nama pasien atau kode ICD-10..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 text-sm border border-gray-200 rounded-lg bg-white outline-none focus:border-green-500 transition-all"
        />
      </div>

      <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-sm text-gray-400">
            Memuat data...
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-sm text-gray-400">
            Belum ada rekam medis
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 text-xs text-gray-400 uppercase tracking-wide">
                <th className="px-5 py-3 text-left font-medium">Pasien</th>
                <th className="px-5 py-3 text-left font-medium">Keluhan</th>
                <th className="px-5 py-3 text-left font-medium">Diagnosis</th>
                <th className="px-5 py-3 text-left font-medium">Terapis</th>
                <th className="px-5 py-3 text-left font-medium">Tanggal</th>
                <th className="px-5 py-3 text-left font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => (
                <tr
                  key={r.id}
                  className="border-t border-gray-50 hover:bg-gray-50 transition-colors"
                >
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                        style={{ backgroundColor: "#F4E6EE", color: "#6B2D4E" }}
                      >
                        {r.patient?.full_name?.[0] ?? "?"}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-800">
                          {r.patient?.full_name}
                        </div>

                        <div className="text-xs text-gray-400">
                          {r.patient?.patient_code}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-sm text-gray-600 max-w-[200px] truncate">
                    {r.chief_complaint ?? "-"}
                  </td>
                  <td className="px-5 py-3">
                    {r.icd10_code ? (
                      <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-purple-50 text-purple-700">
                        {r.icd10_code}
                      </span>
                    ) : (
                      "-"
                    )}
                  </td>
                  <td className="px-5 py-3 text-sm text-gray-600">
                    {r.therapist?.name ?? "-"}
                  </td>

                  <td className="px-5 py-3 text-sm text-gray-400">
                    {new Date(r.created_at).toLocaleDateString("id-ID")}
                  </td>
                  <td className="px-5 py-3">
                    <button
                      onClick={() => navigate(`/medical-records/${r.id}`)}
                      className="text-xs px-3 py-1.5 rounded-lg border border-gray-200 text-gray-500 hover:border-[#6B2D4E] hover:text-[#6B2D4E] transition-colors"
                    >
                      Detail
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
